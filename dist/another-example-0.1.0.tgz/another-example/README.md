# another-example

Example package demonstrating the **generic layout** with `manifests/` and
`templates/` directories instead of the gitups-native `install/` +
`resources/` layout.

Use this as a reference when vendoring a non-gitups package shape (e.g.
porting a Helm chart or a plain manifest bundle) into the catalog. The
packaging contract is controlled by `spec.package.include`/`exclude` in
[package.yaml](package.yaml).

## Layout

```
packages/another-example/
├── package.yaml
├── README.md
├── values.schema.json
├── manifests/
│   └── deployment.yaml
└── templates/
    └── configmap.yaml.tmpl
```

`tools/package-build.sh` uses the override in `spec.package.include` to build
a tarball containing only those paths, even though the default include list
also considers `install/` and `resources/`.
